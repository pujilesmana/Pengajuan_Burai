<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Pengajuan extends CI_Controller
{


	public function Create_pengajuan()
	{
		$post = $this->input->post();
		$kategori = $post['kategori'];
		$nama = $post['nama'];
		$nik = $post['nik'];

		$config['upload_path']          = './assets/dashboard/image/uploads/';
		$config['allowed_types']        = 'jpg|jpeg|bmp|png';
		$config['max_size']             = 0;

		$this->load->library('upload', $config);

		if (!empty($_FILES['ktp']['name']) && !empty($_FILES['kk']['name'])) {
			if ($_FILES['ktp']['type'] == "image/jpeg" || $_FILES['ktp']['type'] == "image/png" || $_FILES['ktp']['type'] == "image/bmp" || $_FILES['ktp']['type'] == "image/jpg") {
				if ($_FILES['kk']['type'] == "image/jpeg" || $_FILES['kk']['type'] == "image/png" || $_FILES['kk']['type'] == "image/bmp" || $_FILES['kk']['type'] == "image/jpg") {
					if ($this->upload->do_upload('ktp')) {

						$uploadData = $this->upload->data();
						$gambarKTP = $uploadData['file_name'];
						$filterGambarKTP = str_replace(" ", "", $gambarKTP);

						if ($this->upload->do_upload('kk')) {

							$uploadData = $this->upload->data();
							$gambarKK = $uploadData['file_name'];
							$filterGambarKK = str_replace(" ", "", $gambarKK);

							$this->pengajuan->addPengajuan($nama, $nik, $kategori, $filterGambarKTP, $filterGambarKK);
							echo 1;
						}
					}
				} else {
					echo 6;
				}
			} else {
				echo 5;
			}
		} else {
			echo 2;
		}
	}
}
